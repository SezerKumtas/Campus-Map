var json_AGAC_A_4 = {
"type": "FeatureCollection",
"name": "AGAC_A_4",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [

]
}
